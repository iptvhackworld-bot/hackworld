const Economy =
require(
  '../models/Economy'
)

/*
|--------------------------------------------------------------------------
| GET ECONOMY
|--------------------------------------------------------------------------
*/

const getEconomy =
async (userId) => {

  let economy =

    await Economy.findOne({

      userId

    })

  /*
  |--------------------------------------------------------------------------
  | CREATE
  |--------------------------------------------------------------------------
  */

  if (!economy) {

    economy =
      await Economy.create({

        userId

      })

  }

  return economy

}

/*
|--------------------------------------------------------------------------
| ADD MONEY
|--------------------------------------------------------------------------
*/

const addMoney =
async (

  userId,

  amount

) => {

  const economy =
    await getEconomy(
      userId
    )

  economy.balance +=
    amount

  await economy.save()

  return economy

}

/*
|--------------------------------------------------------------------------
| REMOVE MONEY
|--------------------------------------------------------------------------
*/

const removeMoney =
async (

  userId,

  amount

) => {

  const economy =
    await getEconomy(
      userId
    )

  economy.balance -=
    amount

  /*
  |--------------------------------------------------------------------------
  | NEGATIVE
  |--------------------------------------------------------------------------
  */

  if (
    economy.balance < 0
  ) {

    economy.balance = 0

  }

  await economy.save()

  return economy

}

module.exports = {

  getEconomy,

  addMoney,

  removeMoney

}